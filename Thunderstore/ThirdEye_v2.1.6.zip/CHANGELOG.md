> # Update Information (Latest listed first)
> ### v2.1.6
> - Recompiled for Valheim 0.217.46
> ### v2.1.5
> - Recompiled for Valheim 0.217.22
> ### v2.1.4
> - Recompiled for Valheim 0.217.14.
> ### v2.1.3
> - Updated for Valheim 0.216.9
> - Filter out tames option.
> ### v2.0.3
> - Mistlands update
> ### v2.0.1/2.0.2
> - Update ServerSync internally
> ### v2.0.0
> - Update ServerSync and SkillManager internally
> - Changed the config file name to be more consistent with my other mods. (Azumatt.ThirdEye.cfg)
> ### v1.0.0
> - Initial Release